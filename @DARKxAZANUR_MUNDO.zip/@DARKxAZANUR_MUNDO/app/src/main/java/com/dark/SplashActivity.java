package com.dark;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class SplashActivity extends Activity {

    private TextView loadingText;
    private String hackerText = "> INITIALIZING SYSTEM...\n> ESTABLISHING CONNECTION...\n> BYPASSING FIREWALL...\n> ACCESS GRANTED.";
    private int charIndex = 0;
    private Handler typingHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.dark.R.layout.activity_splash);

        loadingText = findViewById(com.dark.R.id.loadingText);
        loadingText.setText("");
        
        // Start typing animation
        typingHandler.postDelayed(typingRunnable, 200);

        // 3.5 seconds delay to allow typing to finish
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                typingHandler.removeCallbacks(typingRunnable);
                Intent intent = new Intent(SplashActivity.this, LogAct.class);
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        }, 3500);
    }

    private Runnable typingRunnable = new Runnable() {
        @Override
        public void run() {
            if (charIndex <= hackerText.length()) {
                loadingText.setText(hackerText.substring(0, charIndex) + "_");
                charIndex++;
                typingHandler.postDelayed(this, 35); // 35ms per character
            } else {
                loadingText.setText(hackerText); // Remove cursor at the end
            }
        }
    };
}
