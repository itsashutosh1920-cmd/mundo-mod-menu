package com.dark.utils;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.dark.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import net_62v.external.MetaPackageManager;
import net_62v.external.MetaStorageManager;

@Obfuscate
public class AppManager extends AppCompatActivity {

    private final Context ctx;

    public static final int INSTALL_APP = 1;
    public static final int COPY_OBB = 3;

    public interface CopyCallback {
        void onCopyCompleted(boolean success);
    }

    public AppManager(Context ctx) {
        this.ctx = ctx;
    }

    @SuppressLint("StaticFieldLeak")
    public void appManager(String pkg, int method) {

        new AsyncTask<Void, Integer, Boolean>() {

            String errorMessage = "";

            Dialog progressDialog;
            ProgressBar progressBar;
            TextView progressText;

            long totalBytes = 0;
            long copiedBytes = 0;

            @Override
            protected void onPreExecute() {

                if (method == COPY_OBB) {

                    progressDialog = new Dialog(ctx);
                    progressDialog.setContentView(R.layout.progress_dialog);
                    progressDialog.setCancelable(false);

                    progressBar = progressDialog.findViewById(R.id.progressBar);
                    progressText = progressDialog.findViewById(R.id.progressText);

                    if (progressBar != null) {
                        progressBar.setMax(100);
                        progressBar.setProgress(0);
                    }

                    if (progressText != null) {
                        progressText.setText("0%");
                    }

                    progressDialog.show();
                }
            }

            @Override
            protected Boolean doInBackground(Void... voids) {

                if (method == COPY_OBB) {
                    return copyObbFolder();
                }

                if (method == INSTALL_APP) {
                    return installApp(pkg);
                }

                return false;
            }

            @Override
            protected void onProgressUpdate(Integer... values) {

                if (progressBar != null) {
                    progressBar.setProgress(values[0]);
                }

                if (progressText != null) {
                    progressText.setText(values[0] + "%");
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {

                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }

                showResultDialog(success, errorMessage);
            }

            private boolean installApp(String pkg) {

                try {

                    PackageInfo packageInfo = ctx.getPackageManager().getPackageInfo(pkg, 0);

                    String apkPath = packageInfo.applicationInfo.sourceDir;

                    net_62v.external.MetaApplicationInstaller.installAppByPath(apkPath);

                    boolean result = MetaPackageManager.isInnerAppInstalled(pkg);

                    if (!result) {
                        errorMessage = "Sandbox install failed!";
                        return false;
                    }

                    return true;

                } catch (PackageManager.NameNotFoundException e) {
                    errorMessage = "Package not found!";
                    return false;

                } catch (Exception e) {
                    errorMessage = e.getMessage();
                    return false;
                }
            }

            private boolean copyObbFolder() {

                try {

                    File sourceDir = new File("/storage/emulated/0/Android/obb/" + pkg);

                    if (!sourceDir.exists()) {
                        errorMessage = "OBB folder not found!";
                        return false;
                    }

                    File destDir = getMundoObbDir(pkg);

                    if (sourceDir.getAbsolutePath().equals(destDir.getAbsolutePath())) {
                        return true;
                    }

                    if (!destDir.exists()) {
                        destDir.mkdirs();
                    }

                    totalBytes = getFolderSize(sourceDir);
                    copiedBytes = 0;

                    return copyDirectory(sourceDir, destDir);

                } catch (Exception e) {
                    errorMessage = e.getMessage();
                    return false;
                }
            }

            private boolean copyDirectory(File source, File target) {

                try {

                    if (source.isDirectory()) {

                        if (!target.exists()) {
                            target.mkdirs();
                        }

                        File[] files = source.listFiles();

                        if (files != null) {
                            for (File file : files) {
                                if (!copyDirectory(file, new File(target, file.getName()))) {
                                    return false;
                                }
                            }
                        }

                    } else {

                        FileInputStream input = new FileInputStream(source);
                        FileOutputStream output = new FileOutputStream(target);

                        byte[] buffer = new byte[8192];
                        int length;

                        while ((length = input.read(buffer)) > 0) {
                            output.write(buffer, 0, length);
                            copiedBytes += length;

                            int progress = (int) ((copiedBytes * 100) / totalBytes);
                            publishProgress(progress);
                        }

                        input.close();
                        output.flush();
                        output.close();
                    }

                    return true;

                } catch (Exception e) {
                    errorMessage = e.getMessage();
                    return false;
                }
            }

            private long getFolderSize(File dir) {

                long size = 0;
                File[] files = dir.listFiles();

                if (files != null) {
                    for (File file : files) {
                        if (file.isDirectory()) {
                            size += getFolderSize(file);
                        } else {
                            size += file.length();
                        }
                    }
                }

                return size;
            }

            private void showResultDialog(boolean success, String errorMessage) {

                new MaterialAlertDialogBuilder(ctx)
                        .setTitle(success ? "Success" : "Error")
                        .setMessage(success ? (method == INSTALL_APP ? "App installed successfully." : "OBB ready successfully.") : errorMessage)
                        .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                        .show();
            }

        }.execute();
    }

    private File getMundoObbDir(String pkg) {
        try {
            return new File(
                    MetaStorageManager.obtainAppExternalStorageDir(pkg) + "/Android/obb",
                    pkg
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // FIXED: Now accepts a String parameter for package name
    public boolean checkObbContainer(String packageName) {
        File destDir = getMundoObbDir(packageName);
        return destDir.exists() && destDir.isDirectory() && destDir.listFiles() != null && destDir.listFiles().length > 0;
    }

    public void copyObbFolderAsync(final CopyCallback callback) {

        if (checkObbContainer("com.pubg.imobile")) {
            if (callback != null) {
                callback.onCopyCompleted(true);
            }
            return;
        }

        appManager("com.pubg.imobile", COPY_OBB);
    }
}