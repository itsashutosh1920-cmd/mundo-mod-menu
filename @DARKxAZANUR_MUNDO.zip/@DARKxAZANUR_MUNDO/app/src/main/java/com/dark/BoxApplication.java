package com.dark;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.io.File;

import net_62v.external.IMundoProcessCallback;
import net_62v.external.MetaActivationManager;
import net_62v.external.MetaCore;

public class BoxApplication extends Application implements IMundoProcessCallback {

    static {
        System.loadLibrary("dark");
    }

    public static native String getSdkKey();

    private static final String TAG = "BoxApplication";
    public static BoxApplication gApp;

    public static BoxApplication get() {
        return gApp;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        MetaCore.setProcessLifecycleCallback(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        gApp = this;

        Log.d(TAG, "BoxApplication onCreate started");

        try {
            MetaActivationManager.activateSdk(getSdkKey());
            Log.d(TAG, "Mundo SDK activation called successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate activation", e);
        }
    }

    @Override
    public void onCreate(String s, String s1) {

        if (s.equals("com.pubg.imobile")) {
            // Get the user preference for hide_esp
            android.content.SharedPreferences sp = getSharedPreferences("settings", Context.MODE_PRIVATE);
            boolean hideEsp = sp.getBoolean("hide_esp", false);
            String targetLibName = hideEsp ? "libhide.so" : "libbgmi.so";

            String p1 = new File(getFilesDir(), "loader").getAbsolutePath();

            // 1. Load libbypass.so first if it exists
            File bypassLib = new File(p1, "libbypass.so");
            if (bypassLib.exists()) {
                try {
                    Log.d(TAG, "Loading bypass first: " + bypassLib.getName());
                    System.load(bypassLib.getAbsolutePath());
                } catch (UnsatisfiedLinkError e) {
                    Log.e(TAG, "Failed to load bypass: " + e.getMessage());
                }
            }

            // 2. Load the selected target library (libbgmi.so or libhide.so)
            File targetLib = new File(p1, targetLibName);
            if (targetLib.exists()) {
                try {
                    Log.d(TAG, "Loading target library: " + targetLib.getName());
                    System.load(targetLib.getAbsolutePath());
                } catch (UnsatisfiedLinkError e) {
                    Log.e(TAG, "Failed to load target library: " + e.getMessage());
                }
            }

            // 3. Load any other .so files in the directory (excluding bypass, bgmi, and hide)
            File[] file2 = new File(p1).listFiles();
            if (file2 != null) {
                for (File file1 : file2) {
                    String name = file1.getName();
                    if (name.contains(".so") && !name.equals("libbypass.so") 
                            && !name.equals("libbgmi.so") && !name.equals("libhide.so")) {
                        try {
                            Log.d(TAG, "Loading other library: " + name);
                            System.load(file1.getAbsolutePath());
                        } catch (UnsatisfiedLinkError e) {
                            Log.e(TAG, "Failed to load other library: " + e.getMessage());
                        }
                    }
                }
            }
        }
    }
}