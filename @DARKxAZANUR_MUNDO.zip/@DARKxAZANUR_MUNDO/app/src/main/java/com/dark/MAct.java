package com.dark;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.content.pm.PackageManager;
import com.dark.utils.AppManager;
import com.dark.utils.Prefs;

import org.lsposed.lsparanoid.Obfuscate;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.CRC32;

import net_62v.external.MetaActivationManager;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaPackageManager;
import net_62v.external.MetaStorageManager;

@Obfuscate
public class MAct extends AppCompatActivity {

    static {
        try {
            System.loadLibrary("dark");
        } catch (UnsatisfiedLinkError ignored) {}
    }
    public static native String apkcrc(); // returns the expected CRC32 as string
    private static final String PKG_BGMI = "com.pubg.imobile";

    private ProgressBar progressBar;
    private TextView progressText;
    private boolean isObbCopied = false;
    private AppManager appManager;
    public static native String exdate();
    
    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Make status bar transparent - FIX FOR WHITE BAR ON TOP
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | 
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR  // For dark status bar icons (remove for white icons)
            );
        }
        
        setContentView(R.layout.activity_main);

        // Remove or comment this line - it's causing issues
        // getWindow().setStatusBarColor(getColor(R.color.background));
        
        appManager = new AppManager(this);
        doCountTimerAccout();

        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);

        // BGMI START / INSTALL
        Button startBgmi = findViewById(R.id.startBgmi);
        startBgmi.setOnClickListener(v -> handleLaunchFlow());

        // CLEAR LOGIN - Only button now
        Button btnClearLogin = findViewById(R.id.btnClearLogin);
        if (btnClearLogin != null) {
            btnClearLogin.setOnClickListener(v -> handleClearLogin());
        }

        // SWITCHES
        // Hide ESP toggle logic removed, forcing libbgmi.so usage as requested.
    }

    private void handleLaunchFlow() {
        // First check Mundo activation status
        try {
            if (!MetaActivationManager.getActivationStatus()) {
                Toast.makeText(this, "Mundo Activation Failed", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (Exception e) {
            Log.e("MAct", "Error checking activation status", e);
        }

        String requiredLib = "libbgmi.so";
        File libFile = new File(getFilesDir(), "loader/" + requiredLib);

        if (!libFile.exists()) {
            new AlertDialog.Builder(this)
                    .setTitle("Maintenance Mode")
                    .setMessage("BGMI Engine (" + requiredLib + ") is currently under maintenance or updating. Please try again after the update.")
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .setCancelable(false)
                    .show();
            return;
        }

        // Verify if app is installed inside sandbox using Mundo API
        try {
            if (!MetaPackageManager.isInnerAppInstalled(PKG_BGMI)) {
                appManager.appManager(PKG_BGMI, AppManager.INSTALL_APP);
                Toast.makeText(this, "Installing game into Mundo sandbox. Please wait...", Toast.LENGTH_SHORT).show();
                return; // Return and wait for installation callback
            }
        } catch (Exception e) {
            Log.e("MAct", "Error checking package installation in Mundo sandbox", e);
        }

        // Check if OBB file already exists in the target location
        try {
            PackageInfo info = getPackageManager().getPackageInfo(PKG_BGMI, 0);
            String gameObb = "main." + info.versionCode + "." + info.packageName + ".obb";
            
            // In Mundo, target sandbox directory redirects standard paths or we can let the system standard copy handle it
            // We verify path using our AppManager standard container structure
            if (appManager.checkObbContainer(PKG_BGMI)) {
                launchGame(); // OBB exists, launch the game directly
                return;
            }
        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this, "Could not get package info.", Toast.LENGTH_SHORT).show();
        }

        // If OBB doesn't exist, start the copy process
        if (!isObbCopied) {
            copyObbFiles();
        } else {
            launchGame();
        }
    }

    private void handleClearLogin() {
        try {
            // Stop cloned package under Mundo sandbox
            MetaActivityManager.killAppByPkg(PKG_BGMI);
            // Delete standard sandbox user 0 game preferences manually to clear login
            File gameDataDir = new File("/data/data/" + getPackageName() + "/virtual/data/user/0/" + PKG_BGMI);
            if (gameDataDir.exists()) {
                deleteDirRecursively(gameDataDir);
            }
            Toast.makeText(this, "Login data cleared from Mundo sandbox", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to clear login: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean deleteDirRecursively(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            if (children != null) {
                for (String child : children) {
                    boolean success = deleteDirRecursively(new File(dir, child));
                    if (!success) {
                        return false;
                    }
                }
            }
        }
        return dir.delete();
    }

    private void doCountTimerAccout() {
        android.os.Handler handler = new android.os.Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    handler.postDelayed(this, 1000);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date expiryDate = dateFormat.parse(exdate());
                    long now = System.currentTimeMillis();
                    long distance = expiryDate.getTime() - now;

                    long d = distance / (24 * 60 * 60 * 1000);
                    long h = (distance / (60 * 60 * 1000)) % 24;
                    long m = (distance / (60 * 1000)) % 60;
                    long s = (distance / 1000) % 60;

                    if (distance < 0) {
                        Toast.makeText(MAct.this, "License expired!", Toast.LENGTH_SHORT).show();
                    } else {
                        ((TextView) findViewById(R.id.tvD)).setText(String.format("%02d", d));
                        ((TextView) findViewById(R.id.tvH)).setText(String.format("%02d", h));
                        ((TextView) findViewById(R.id.tvM)).setText(String.format("%02d", m));
                        ((TextView) findViewById(R.id.tvS)).setText(String.format("%02d", s));
                    }
                } catch (Exception ignored) {}
            }
        };
        handler.postDelayed(runnable, 0);
    }

    private void copyObbFiles() {
        findViewById(R.id.progressCard).setVisibility(android.view.View.VISIBLE);
        progressText.setText("Copying OBB...");
        progressBar.setProgress(0);

        new Thread(() -> {
            try {
                PackageInfo info = getPackageManager().getPackageInfo(PKG_BGMI, 0);
                String gameObb = "main." + info.versionCode + "." + info.packageName + ".obb";

                // Resolve Mundo destination OBB directory mapping
                File obbDestDir = new File(
                        MetaStorageManager.obtainAppExternalStorageDir(PKG_BGMI) + "/Android/obb",
                        PKG_BGMI
                );
                if (!obbDestDir.exists()) obbDestDir.mkdirs();

                File obbSource = null;
                StorageManager sm = (StorageManager) getSystemService(STORAGE_SERVICE);
                for (StorageVolume storageVolume : sm.getStorageVolumes()) {
                    File obbDir;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        obbDir = storageVolume.getDirectory();
                    } else {
                        try {
                            Method getPathFile = StorageVolume.class.getMethod("getPathFile");
                            obbDir = (File) getPathFile.invoke(storageVolume);
                        } catch (Exception e) {
                            Log.e("MAct", "Failed to get path from StorageVolume via reflection", e);
                            obbDir = null;
                        }
                    }

                    if (obbDir != null) {
                        File obbSubDir = new File(obbDir, "Android/obb/" + PKG_BGMI);
                        File obbFile = new File(obbSubDir, gameObb);
                        if (obbFile.exists() && obbFile.canRead()) {
                            obbSource = obbFile;
                            break;
                        }
                    }
                }

                File obbDestFile = new File(obbDestDir, gameObb);
                if (obbDestFile.exists()) {
                    runOnUiThread(() -> {
                        isObbCopied = true;
                        launchGame();
                    });
                    return;
                }

                final File finalObbSource = obbSource;
                if (obbSource == null || !obbSource.exists() || !obbSource.canRead()) {
                    runOnUiThread(() -> Toast.makeText(this, "OBB source file not found or is not readable: " + (finalObbSource != null ? finalObbSource.getAbsolutePath() : "null"), Toast.LENGTH_LONG).show());
                    return;
                }

                java.io.FileInputStream fis = new java.io.FileInputStream(obbSource);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(obbDestFile);

                long total = obbSource.length();
                long copied = 0;
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                    copied += len;
                    int prog = (int) ((copied * 100) / total);
                    runOnUiThread(() -> {
                        progressBar.setProgress(prog);
                        progressText.setText("Copying OBB: " + prog + "%");
                    });
                }
                fis.close();
                fos.close();

                runOnUiThread(() -> {
                    isObbCopied = true;
                    progressText.setText("Ready to launch");
                    launchGame();
                });

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "OBB copy failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /** Launch BGMI using Mundo API */
    private void launchGame() {
        try {
            Intent intent = MetaActivityManager.obtainSplashLaunchIntent(PKG_BGMI, this);
            if (intent != null) {
                startActivity(intent);
                Toast.makeText(this, "Launching BGMI in Mundo sandbox...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to obtain Mundo launch intent", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Launch failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            MetaActivityManager.killAppByPkg(PKG_BGMI);
        } catch (Exception e) {
            Log.e("MAct", "Error killing app in onDestroy", e);
        }
    }
}